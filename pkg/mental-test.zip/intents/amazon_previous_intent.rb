# frozen_string_literal: true

intent 'AMAZON.PreviousIntent' do
  respond('TBD Previous')
end
