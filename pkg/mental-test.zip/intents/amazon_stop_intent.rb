# frozen_string_literal: true

intent 'AMAZON.StopIntent' do
  tell('goodbye')
end
