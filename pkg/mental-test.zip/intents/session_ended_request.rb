# frozen_string_literal: true

intent 'SessionEndedRequest' do
  respond
end
