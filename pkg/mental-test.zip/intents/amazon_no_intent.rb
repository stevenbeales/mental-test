# frozen_string_literal: true

intent 'AMAZON.NoIntent' do
  respond('No')
end
