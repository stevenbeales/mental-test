# frozen_string_literal: true

intent 'AMAZON.NextIntent' do
  respond('TBD Next')
end
