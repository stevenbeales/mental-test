# frozen_string_literal: true

intent 'AMAZON.ResumeIntent' do
  respond('Resume')
end
