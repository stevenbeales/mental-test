# frozen_string_literal: true

intent 'AMAZON.YesIntent' do
  respond('Yes')
end
