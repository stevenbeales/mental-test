# frozen_string_literal: true

intent 'AMAZON.RepeatIntent' do
  respond('TBD Repeat')
end
