# frozen_string_literal: true

intent 'AMAZON.CancelIntent' do
  ask('OK, what would you like to say?')
end
