# frozen_string_literal: true

intent 'AMAZON.MoreIntent' do
  respond AlexaHelp.default_help_response
end
