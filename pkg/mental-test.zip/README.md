# mental-test
Alexa Ruby Skill for Mental Health Assessments

[![Build Status](https://travis-ci.org/stevenbeales/mental-test.png)](https://travis-ci.org/stevenbeales/mental-test)
