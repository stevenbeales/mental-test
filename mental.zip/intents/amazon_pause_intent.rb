# frozen_string_literal: true

intent 'AMAZON.PauseIntent' do
  respond('Pause')
end
